const express = require("express");

const eventController = require("../controllers/eventController");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/", eventController.getAll);
router.get("/:id", eventController.getById);

router.post(
  "/",
  authMiddleware,
  eventController.create
);

router.put(
  "/:id",
  authMiddleware,
  eventController.update
);

router.delete(
  "/:id",
  authMiddleware,
  eventController.delete
);

module.exports = router;